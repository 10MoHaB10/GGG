import os
TOKEN = os.environ.get("BOT_TOKEN")
print("BOT_TOKEN =", TOKEN)  # للتأكد فقط
import os
import json
from typing import Dict, Any
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (Application, CommandHandler, MessageHandler,
                          CallbackQueryHandler, filters, ContextTypes,
                          ConversationHandler)
import time
import logging
import asyncio
import threading
from fastapi import FastAPI
import uvicorn
import os
TOKEN = os.environ.get("BOT_TOKEN")
# Constants
OWNER_ID = 6871615592

DATA_FILE = "data.json"
WELCOME_FILE = "welcome.txt"
BUTTONS_FILE = "buttons.json"
CUSTOM_BUTTONS_FILE = "custom_buttons.json"
QUIZZES_FILE = "quizzes.json"
QUIZ_SCORES_FILE = "quiz_scores.json"
POLLS_FILE = "polls.json"

# FastAPI app instance
app = FastAPI(title="MoH Harvard Bot Web Server", version="1.0.0")

# حالات المحادثة
ADDING_KEYWORD, ADDING_RESPONSE, ADDING_BUTTON_TEXT, ADDING_BUTTON_URL, ADDING_CUSTOM_BUTTON_TEXT, ADDING_CUSTOM_BUTTON_RESPONSE, EDITING_REPLY, EDITING_BUTTON_TEXT, EDITING_BUTTON_URL, EDITING_CUSTOM_BUTTON_TEXT, EDITING_CUSTOM_BUTTON_RESPONSE, ADDING_QUIZ_QUESTION, ADDING_QUIZ_OPTIONS, ADDING_QUIZ_CORRECT_ANSWER, ADDING_QUIZ_TIME, ADDING_POLL_QUESTION, ADDING_POLL_OPTIONS = range(
    17)

# متغيرات مؤقتة
user_data = {}

# ---------------------------- ملفات البيانات ----------------------------


def load_data():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_welcome():
    if not os.path.exists(WELCOME_FILE):
        return "مرحبا بك في MoH هارفد بوت"
    with open(WELCOME_FILE, "r", encoding="utf-8") as f:
        return f.read()


def save_welcome(text):
    with open(WELCOME_FILE, "w", encoding="utf-8") as f:
        f.write(text)


def load_buttons():
    if not os.path.exists(BUTTONS_FILE):
        return []
    with open(BUTTONS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_buttons(buttons):
    with open(BUTTONS_FILE, "w", encoding="utf-8") as f:
        json.dump(buttons, f, ensure_ascii=False, indent=2)


def load_custom_buttons():
    if not os.path.exists(CUSTOM_BUTTONS_FILE):
        return {}
    with open(CUSTOM_BUTTONS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_custom_buttons(custom_buttons):
    with open(CUSTOM_BUTTONS_FILE, "w", encoding="utf-8") as f:
        json.dump(custom_buttons, f, ensure_ascii=False, indent=2)


def load_quizzes():
    if not os.path.exists(QUIZZES_FILE):
        return {}
    with open(QUIZZES_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_quizzes(quizzes):
    with open(QUIZZES_FILE, "w", encoding="utf-8") as f:
        json.dump(quizzes, f, ensure_ascii=False, indent=2)


def load_quiz_scores():
    if not os.path.exists(QUIZ_SCORES_FILE):
        return {}
    with open(QUIZ_SCORES_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_quiz_scores(scores):
    with open(QUIZ_SCORES_FILE, "w", encoding="utf-8") as f:
        json.dump(scores, f, ensure_ascii=False, indent=2)


def load_polls():
    if not os.path.exists("polls.json"):
        return {}
    with open("polls.json", "r", encoding="utf-8") as f:
        return json.load(f)


def save_polls(polls):
    with open("polls.json", "w", encoding="utf-8") as f:
        json.dump(polls, f, ensure_ascii=False, indent=2)


# ---------------------------- التحقق من الصلاحيات ----------------------------


def is_owner(user_id):
    return user_id == OWNER_ID


# ---------------------------- أوامر البوت ----------------------------


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome_text = load_welcome()
    buttons = load_buttons()
    custom_buttons = load_custom_buttons()

    # إضافة الأزرار المخصصة (URL)
    keyboard = []
    for button in buttons:
        keyboard.append(
            [InlineKeyboardButton(button["text"], url=button["url"])])

    # إضافة الأزرار المخصصة (ملفات ونصوص)
    for button_id, button_data in custom_buttons.items():
        keyboard.append([
            InlineKeyboardButton(button_data["text"],
                                 callback_data=f"custom_btn_{button_id}")
        ])

    # إضافة أزرار التحكم للمالك فقط
    if is_owner(update.effective_user.id):
        keyboard.append([
            InlineKeyboardButton("🔧 لوحة التحكم", callback_data="admin_panel")
        ])

    keyboard.append(
        [InlineKeyboardButton("📋 عرض جميع الكلمات", callback_data="list_all")])

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(welcome_text, reply_markup=reply_markup)


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "admin_panel":
        if not is_owner(query.from_user.id):
            await query.edit_message_text("❌ هذا الأمر مخصص للمالك فقط!")
            return

        keyboard = [
            [
                InlineKeyboardButton("➕ إضافة رد جديد",
                                     callback_data="add_reply")
            ],
            [InlineKeyboardButton("🗑️ حذف رد", callback_data="delete_reply")],
            [InlineKeyboardButton("✏️ تعديل رد", callback_data="edit_reply")],
            [
                InlineKeyboardButton("➕ إضافة زر رابط",
                                     callback_data="add_button")
            ],
            [
                InlineKeyboardButton("🗑️ حذف زر رابط",
                                     callback_data="delete_button")
            ],
            [
                InlineKeyboardButton("✏️ تعديل زر رابط",
                                     callback_data="edit_button")
            ],
            [
                InlineKeyboardButton("🔘 إضافة زر مخصص",
                                     callback_data="add_custom_button")
            ],
            [
                InlineKeyboardButton("🗑️ حذف زر مخصص",
                                     callback_data="delete_custom_button")
            ],
            [
                InlineKeyboardButton("✏️ تعديل زر مخصص",
                                     callback_data="edit_custom_button")
            ],
            [
                InlineKeyboardButton("🧠 إنشاء كويز",
                                     callback_data="create_quiz")
            ],
            [
                InlineKeyboardButton("📋 عرض الكويزات",
                                     callback_data="view_quizzes")
            ],
            [InlineKeyboardButton("🗑️ حذف كويز", callback_data="delete_quiz")],
            [
                InlineKeyboardButton("📊 إنشاء استطلاع",
                                     callback_data="create_poll")
            ],
            [
                InlineKeyboardButton("📋 عرض الاستطلاعات",
                                     callback_data="view_polls")
            ],
            [
                InlineKeyboardButton("🗑️ حذف استطلاع",
                                     callback_data="delete_poll")
            ],
            [
                InlineKeyboardButton("🏆 جدول المتصدرين",
                                     callback_data="leaderboard")
            ],
            [
                InlineKeyboardButton("📝 تعديل الترحيب",
                                     callback_data="edit_welcome")
            ], [InlineKeyboardButton("📊 الإحصائيات", callback_data="stats")],
            [InlineKeyboardButton("🔙 العودة", callback_data="back_to_start")]
        ]
        await query.edit_message_text(
            "🔧 لوحة التحكم الإدارية:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == "list_all":
        data = load_data()
        if not data:
            await query.edit_message_text("❌ لا توجد كلمات محفوظة بعد!")
            return

        text = "📋 جميع الكلمات المحفوظة:\n\n"
        for keyword in data.keys():
            text += f"• {keyword}\n"

        keyboard = [[
            InlineKeyboardButton("🔙 العودة", callback_data="back_to_start")
        ]]
        await query.edit_message_text(
            text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == "delete_reply":
        if not is_owner(query.from_user.id):
            return
        data = load_data()
        if not data:
            await query.edit_message_text("❌ لا توجد ردود لحذفها!")
            return

        keyboard = []
        for keyword in list(data.keys())[:20]:  # عرض أول 20 كلمة
            keyboard.append([
                InlineKeyboardButton(f"🗑️ {keyword}",
                                     callback_data=f"del_reply_{keyword}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "🗑️ اختر الكلمة التي تريد حذفها:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("del_reply_"):
        if not is_owner(query.from_user.id):
            return
        keyword = query.data.replace("del_reply_", "")
        data = load_data()
        if keyword in data:
            del data[keyword]
            save_data(data)
            await query.edit_message_text(f"✅ تم حذف الرد للكلمة: {keyword}")
        else:
            await query.edit_message_text("❌ لم يتم العثور على هذه الكلمة!")

    elif query.data == "delete_button":
        if not is_owner(query.from_user.id):
            return
        buttons = load_buttons()
        if not buttons:
            await query.edit_message_text("❌ لا توجد أزرار لحذفها!")
            return

        keyboard = []
        for i, button in enumerate(buttons):
            keyboard.append([
                InlineKeyboardButton(f"🗑️ {button['text']}",
                                     callback_data=f"del_btn_{i}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "🗑️ اختر الزر التي تريد حذفه:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("del_btn_"):
        if not is_owner(query.from_user.id):
            return
        btn_index = int(query.data.replace("del_btn_", ""))
        buttons = load_buttons()
        if 0 <= btn_index < len(buttons):
            deleted_button = buttons.pop(btn_index)
            save_buttons(buttons)
            await query.edit_message_text(
                f"✅ تم حذف الزر: {deleted_button['text']}")
        else:
            await query.edit_message_text("❌ لم يتم العثور على هذا الزر!")

    elif query.data == "delete_custom_button":
        if not is_owner(query.from_user.id):
            return
        custom_buttons = load_custom_buttons()
        if not custom_buttons:
            await query.edit_message_text("❌ لا توجد أزرار مخصصة لحذفها!")
            return

        keyboard = []
        for button_id, button_data in custom_buttons.items():
            keyboard.append([
                InlineKeyboardButton(
                    f"🗑️ {button_data['text']}",
                    callback_data=f"del_custom_btn_{button_id}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "🗑️ اختر الزر المخصص الذي تريد حذفه:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("del_custom_btn_"):
        if not is_owner(query.from_user.id):
            return
        button_id = query.data.replace("del_custom_btn_", "")
        custom_buttons = load_custom_buttons()
        if button_id in custom_buttons:
            deleted_button = custom_buttons.pop(button_id)
            save_custom_buttons(custom_buttons)
            await query.edit_message_text(
                f"✅ تم حذف الزر المخصص: {deleted_button['text']}")
        else:
            await query.edit_message_text("❌ لم يتم العثور على هذا الزر!")

    elif query.data == "edit_reply":
        if not is_owner(query.from_user.id):
            return
        data = load_data()
        if not data:
            await query.edit_message_text("❌ لا توجد ردود للتعديل!")
            return

        keyboard = []
        for keyword in list(data.keys())[:20]:
            keyboard.append([
                InlineKeyboardButton(f"✏️ {keyword}",
                                     callback_data=f"edit_reply_{keyword}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "✏️ اختر الكلمة التي تريد تعديلها:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("edit_reply_"):
        if not is_owner(query.from_user.id):
            return
        keyword = query.data.replace("edit_reply_", "")
        data = load_data()
        if keyword in data:
            current_data = data[keyword]
            text = f"✏️ تعديل الرد للكلمة: {keyword}\n\n"
            text += f"📝 النص الحالي: {current_data.get('text', 'لا يوجد')}\n"
            text += f"📎 الملف: {'موجود' if current_data.get('file_id') else 'غير موجود'}\n\n"
            text += "أرسل المحتوى الجديد (نص أو ملف أو الاثنين معاً):"

            user_data[query.from_user.id] = {"edit_keyword": keyword}
            await query.edit_message_text(text)
        else:
            await query.edit_message_text("❌ لم يتم العثور على هذه الكلمة!")

    elif query.data == "edit_button":
        if not is_owner(query.from_user.id):
            return
        buttons = load_buttons()
        if not buttons:
            await query.edit_message_text("❌ لا توجد أزرار للتعديل!")
            return

        keyboard = []
        for i, button in enumerate(buttons):
            keyboard.append([
                InlineKeyboardButton(f"✏️ {button['text']}",
                                     callback_data=f"edit_btn_{i}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "✏️ اختر الزر التي تريد تعديله:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("edit_btn_"):
        if not is_owner(query.from_user.id):
            return
        btn_index = int(query.data.replace("edit_btn_", ""))
        buttons = load_buttons()
        if 0 <= btn_index < len(buttons):
            button = buttons[btn_index]
            text = f"✏️ تعديل الزر:\n\n"
            text += f"📝 النص الحالي: {button['text']}\n"
            text += f"🔗 الرابط الحالي: {button['url']}\n\n"
            text += "أرسل النص الجديد للزر:"

            user_data[query.from_user.id] = {"edit_button_index": btn_index}
            await query.edit_message_text(text)
        else:
            await query.edit_message_text("❌ لم يتم العثور على هذا الزر!")

    elif query.data == "edit_custom_button":
        if not is_owner(query.from_user.id):
            return
        custom_buttons = load_custom_buttons()
        if not custom_buttons:
            await query.edit_message_text("❌ لا توجد أزرار مخصصة للتعديل!")
            return

        keyboard = []
        for button_id, button_data in custom_buttons.items():
            keyboard.append([
                InlineKeyboardButton(
                    f"✏️ {button_data['text']}",
                    callback_data=f"edit_custom_btn_{button_id}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "✏️ اختر الزر المخصص الذي تريد تعديله:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("edit_custom_btn_"):
        if not is_owner(query.from_user.id):
            return
        button_id = query.data.replace("edit_custom_btn_", "")
        custom_buttons = load_custom_buttons()
        if button_id in custom_buttons:
            button_data = custom_buttons[button_id]
            text = f"✏️ تعديل الزر المخصص:\n\n"
            text += f"📝 النص الحالي: {button_data['text']}\n"
            text += f"💬 الرد الحالي: {button_data.get('response_text', 'لا يوجد')}\n"
            text += f"📎 الملف: {'موجود' if button_data.get('file_id') else 'غير موجود'}\n\n"
            text += "أرسل نص الزر الجديد:"

            user_data[query.from_user.id] = {
                "edit_custom_button_id": button_id
            }
            await query.edit_message_text(text)
        else:
            await query.edit_message_text("❌ لم يتم العثور على هذا الزر!")

    elif query.data.startswith("custom_btn_"):
        button_id = query.data.replace("custom_btn_", "")
        custom_buttons = load_custom_buttons()
        if button_id in custom_buttons:
            button_data = custom_buttons[button_id]

            # معالجة خاصة لزر الكويزات
            if button_id == "quizzes_btn":
                quizzes = load_quizzes()
                if not quizzes:
                    await query.edit_message_text(
                        "❌ لا توجد كويزات متاحة حاليًا!")
                    return

                keyboard = []
                for quiz_id, quiz_data in quizzes.items():
                    keyboard.append([
                        InlineKeyboardButton(
                            f"🧠 {quiz_data['question'][:40]}...",
                            callback_data=f"start_quiz_{quiz_id}")
                    ])
                keyboard.append([
                    InlineKeyboardButton("🏆 جدول المتصدرين",
                                         callback_data="user_leaderboard")
                ])
                keyboard.append([
                    InlineKeyboardButton("🔙 العودة للقائمة الرئيسية",
                                         callback_data="back_to_start")
                ])

                await query.edit_message_text(
                    "🧠 الكويزات المتاحة:",
                    reply_markup=InlineKeyboardMarkup(keyboard))
                return

            # إرسال الملفات المتعددة إذا وجدت (دعم حتى 10 ملفات)
            if button_data.get("file_ids") and isinstance(button_data["file_ids"], list):
                for file_id in button_data["file_ids"][:10]:  # حد أقصى 10 ملفات
                    try:
                        await query.message.reply_document(document=file_id)
                    except Exception:
                        continue
            # إرسال ملف واحد (للتوافق مع النظام القديم)
            elif button_data.get("file_id"):
                try:
                    await query.message.reply_document(
                        document=button_data["file_id"])
                except Exception:
                    pass

            # إرسال النص إذا وجد
            if button_data.get("response_text"):
                await query.message.reply_text(button_data["response_text"])

            # إضافة رسالة /start بعد كل رد
            await query.message.reply_text("🔄 للعودة للقائمة الرئيسية: /start")

    elif query.data == "edit_welcome":
        if not is_owner(query.from_user.id):
            return
        current_welcome = load_welcome()
        await query.edit_message_text(
            f"📝 رسالة الترحيب الحالية:\n\n{current_welcome}\n\nأرسل الرسالة الجديدة:"
        )

    elif query.data == "create_poll":
        if not is_owner(query.from_user.id):
            return
        await query.edit_message_text("📊 أرسل سؤال الاستطلاع:")
        user_data[query.from_user.id] = {"creating_poll": True}

    elif query.data == "create_quiz":
        if not is_owner(query.from_user.id):
            return
        await query.edit_message_text("🧠 أرسل السؤال الأول للكويز:")
        user_data[query.from_user.id] = {
            "creating_quiz": True,
            "quiz_questions": []
        }

    elif query.data == "view_polls":
        polls = load_polls()
        if not polls:
            await query.edit_message_text("❌ لا توجد استطلاعات محفوظة!")
            return

        keyboard = []
        for poll_id, poll_data in polls.items():
            keyboard.append([
                InlineKeyboardButton(f"📊 {poll_data['question'][:30]}...",
                                     callback_data=f"show_poll_{poll_id}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "📋 الاستطلاعات المحفوظة:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("show_poll_"):
        poll_id = query.data.replace("show_poll_", "")
        polls = load_polls()
        if poll_id in polls:
            poll_data = polls[poll_id]
            text = f"📊 **{poll_data['question']}**\n\n"
            text += f"📝 عدد الخيارات: {len(poll_data['options'])}\n\n"
            text += "الخيارات:\n"
            for i, option in enumerate(poll_data['options'], 1):
                text += f"{i}. {option}\n"

            keyboard = [[
                InlineKeyboardButton("📤 إرسال الاستطلاع",
                                     callback_data=f"send_poll_{poll_id}")
            ], [InlineKeyboardButton("🔙 العودة", callback_data="view_polls")]]
            await query.edit_message_text(
                text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("send_poll_"):
        poll_id = query.data.replace("send_poll_", "")
        polls = load_polls()
        if poll_id in polls:
            poll_data = polls[poll_id]

            await query.message.reply_poll(
                question=poll_data["question"],
                options=poll_data["options"],
                is_anonymous=poll_data.get("is_anonymous", True),
                allows_multiple_answers=poll_data.get("multiple_answers",
                                                      False))
            await query.answer("✅ تم إرسال الاستطلاع!")

    elif query.data == "delete_poll":
        if not is_owner(query.from_user.id):
            return
        polls = load_polls()
        if not polls:
            await query.edit_message_text("❌ لا توجد استطلاعات لحذفها!")
            return

        keyboard = []
        for poll_id, poll_data in polls.items():
            keyboard.append([
                InlineKeyboardButton(f"🗑️ {poll_data['question'][:30]}...",
                                     callback_data=f"del_poll_{poll_id}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "🗑️ اختر الاستطلاع الذي تريد حذفه:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("del_poll_"):
        if not is_owner(query.from_user.id):
            return
        poll_id = query.data.replace("del_poll_", "")
        polls = load_polls()
        if poll_id in polls:
            deleted_poll = polls.pop(poll_id)
            save_polls(polls)
            await query.edit_message_text(
                f"✅ تم حذف الاستطلاع: {deleted_poll['question']}")
        else:
            await query.edit_message_text("❌ لم يتم العثور على هذا الاستطلاع!")

    elif query.data == "view_quizzes":
        quizzes = load_quizzes()
        if not quizzes:
            await query.edit_message_text("❌ لا توجد كويزات محفوظة!")
            return

        keyboard = []
        for quiz_id, quiz_data in quizzes.items():
            keyboard.append([
                InlineKeyboardButton(f"🧠 {quiz_data['question'][:30]}...",
                                     callback_data=f"show_quiz_{quiz_id}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "📋 الكويزات المحفوظة:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("show_quiz_"):
        quiz_id = query.data.replace("show_quiz_", "")
        quizzes = load_quizzes()
        if quiz_id in quizzes:
            quiz_data = quizzes[quiz_id]

            # التحقق من نوع الكويز (قديم أم جديد)
            if "questions" in quiz_data:
                # كويز متعدد الأسئلة
                text = f"🧠 **كويز متعدد الأسئلة**\n\n"
                text += f"📊 عدد الأسئلة: {quiz_data['total_questions']}\n"
                text += f"🆔 معرف الكويز: {quiz_id}\n\n"
                text += "**معاينة الأسئلة:**\n"

                for i, q in enumerate(quiz_data['questions'][:5], 1):
                    text += f"{i}. {q['question'][:60]}...\n"
                    text += f"   ⏱️ الوقت: {q['time_limit']} ثانية\n"
                    text += f"   ✅ الإجابة: {q['options'][q['correct_answer']]}\n\n"

                if len(quiz_data['questions']) > 5:
                    text += f"... و {len(quiz_data['questions']) - 5} أسئلة أخرى"
            else:
                # كويز قديم بسؤال واحد
                text = f"🧠 **{quiz_data['question']}**\n\n"
                text += f"⏱️ الوقت المحدد: {quiz_data['time_limit']} ثانية\n"
                text += f"✅ الإجابة الصحيحة: {quiz_data['options'][quiz_data['correct_answer']]}\n\n"
                text += "الخيارات:\n"
                for i, option in enumerate(quiz_data['options'], 1):
                    text += f"{i}. {option}\n"

            keyboard = [[
                InlineKeyboardButton("🔙 العودة", callback_data="view_quizzes")
            ]]
            await query.edit_message_text(
                text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("start_quiz_"):
        quiz_id = query.data.replace("start_quiz_", "")
        quizzes = load_quizzes()
        if quiz_id in quizzes:
            quiz_data = quizzes[quiz_id]
            user_id = query.from_user.id

            # حفظ بيانات الكويز المؤقتة
            import time
            user_data[user_id] = {
                "quiz_id": quiz_id,
                "start_time": time.time(),
                "time_limit": quiz_data["time_limit"]
            }

            text = f"🧠 **{quiz_data['question']}**\n\n"
            text += f"⏱️ لديك {quiz_data['time_limit']} ثانية للإجابة!\n\n"

            keyboard = []
            for i, option in enumerate(quiz_data['options']):
                keyboard.append([
                    InlineKeyboardButton(f"{i+1}. {option}",
                                         callback_data=f"answer_{quiz_id}_{i}")
                ])

            await query.edit_message_text(
                text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("answer_"):
        parts = query.data.split("_")
        quiz_id = parts[1]
        answer_index = int(parts[2])
        user_id = query.from_user.id

        if user_id not in user_data or "quiz_id" not in user_data[user_id]:
            await query.answer("❌ انتهت صلاحية الكويز!")
            return

        import time
        current_time = time.time()
        start_time = user_data[user_id]["start_time"]
        time_limit = user_data[user_id]["time_limit"]

        # التحقق من انتهاء الوقت
        if current_time - start_time > time_limit:
            del user_data[user_id]
            await query.answer("⏰ انتهى الوقت المحدد!")
            await query.edit_message_text(
                "⏰ **انتهى الوقت!**\n\nلم تتمكن من الإجابة في الوقت المحدد.")
            return

        quizzes = load_quizzes()
        quiz_data = quizzes[quiz_id]
        correct_answer = quiz_data["correct_answer"]
        time_taken = round(current_time - start_time, 2)

        # حساب النقاط
        base_points = 100
        time_bonus = max(0, time_limit - time_taken) * 2  # نقاط إضافية للسرعة
        total_points = 0

        if answer_index == correct_answer:
            total_points = int(base_points + time_bonus)
            result_text = f"✅ **إجابة صحيحة!**\n\n"
            result_text += f"🏆 النقاط المكتسبة: {total_points}\n"
            result_text += f"⏱️ الوقت المستغرق: {time_taken} ثانية\n"
        else:
            result_text = f"❌ **إجابة خاطئة!**\n\n"
            result_text += f"✅ الإجابة الصحيحة: {quiz_data['options'][correct_answer]}\n"
            result_text += f"⏱️ الوقت المستغرق: {time_taken} ثانية\n"

        # حفظ النتيجة
        scores = load_quiz_scores()
        user_name = query.from_user.first_name or query.from_user.username or str(
            user_id)

        if str(user_id) not in scores:
            scores[str(user_id)] = {
                "name": user_name,
                "total_score": 0,
                "quizzes_completed": 0,
                "correct_answers": 0
            }

        scores[str(user_id)]["total_score"] += total_points
        scores[str(user_id)]["quizzes_completed"] += 1
        if answer_index == correct_answer:
            scores[str(user_id)]["correct_answers"] += 1

        save_quiz_scores(scores)
        del user_data[user_id]

        keyboard = [[
            InlineKeyboardButton("🔙 العودة للكويزات",
                                 callback_data="custom_btn_quizzes_btn")
        ]]
        await query.edit_message_text(
            result_text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == "leaderboard" or query.data == "user_leaderboard":
        scores = load_quiz_scores()
        if not scores:
            await query.edit_message_text("❌ لا توجد نتائج بعد!")
            return

        # ترتيب المستخدمين حسب النقاط
        sorted_users = sorted(scores.items(),
                              key=lambda x: x[1]["total_score"],
                              reverse=True)
        
        text = "🏆 **جدول المتصدرين**\n\n"
        for i, (user_id, data) in enumerate(sorted_users[:10], 1):
            if i == 1:
                medal = "🥇"
            elif i == 2:
                medal = "🥈"
            elif i == 3:
                medal = "🥉"
            else:
                medal = f"{i}."

            accuracy = round(
                (data["correct_answers"] / data["quizzes_completed"]) *
                100, 1) if data["quizzes_completed"] > 0 else 0
            text += f"{medal} **{data['name']}**\n"
            text += f"   📊 النقاط: {data['total_score']}\n"
            text += f"   ✅ دقة الإجابات: {accuracy}%\n"
            text += f"   🎯 الكويزات المكتملة: {data['quizzes_completed']}\n\n"

        if query.data == "leaderboard":
            keyboard = [[
                InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")
            ]]
        else:
            keyboard = [[
                InlineKeyboardButton("🔙 العودة للكويزات",
                                     callback_data="custom_btn_quizzes_btn")
            ]]

        await query.edit_message_text(
            text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == "delete_quiz":
        if not is_owner(query.from_user.id):
            return
        quizzes = load_quizzes()
        if not quizzes:
            await query.edit_message_text("❌ لا توجد كويزات لحذفها!")
            return

        keyboard = []
        for quiz_id, quiz_data in quizzes.items():
            keyboard.append([
                InlineKeyboardButton(f"🗑️ {quiz_data['question'][:30]}...",
                                     callback_data=f"del_quiz_{quiz_id}")
            ])
        keyboard.append(
            [InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")])

        await query.edit_message_text(
            "🗑️ اختر الكويز الذي تريد حذفه:",
            reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith("del_quiz_"):
        if not is_owner(query.from_user.id):
            return
        quiz_id = query.data.replace("del_quiz_", "")
        quizzes = load_quizzes()
        if quiz_id in quizzes:
            deleted_quiz = quizzes.pop(quiz_id)
            save_quizzes(quizzes)
            await query.edit_message_text(
                f"✅ تم حذف الكويز: {deleted_quiz['questions'][0]['question'] if 'questions' in deleted_quiz else deleted_quiz['question']}"
            )
        else:
            await query.edit_message_text("❌ لم يتم العثور على هذا الكويز!")

    elif query.data == "add_another_question":
        if not is_owner(query.from_user.id):
            return
        await query.edit_message_text("🧠 أرسل السؤال التالي:")
        # إعادة تعيين العلامة لإضافة سؤال جديد

    elif query.data == "save_quiz":
        if not is_owner(query.from_user.id):
            return

        user_id = query.from_user.id
        if user_id not in user_data or "quiz_questions" not in user_data[
                user_id]:
            await query.edit_message_text("❌ لا توجد أسئلة للحفظ!")
            return

        quiz_questions = user_data[user_id]["quiz_questions"]

        if not quiz_questions:
            await query.edit_message_text("❌ لا توجد أسئلة للحفظ!")
            return

        quizzes = load_quizzes()

        import time
        quiz_id = str(int(time.time()))

        quiz_data = {
            "questions": quiz_questions,
            "created_by": user_id,
            "created_at": quiz_id,
            "total_questions": len(quiz_questions)
        }

        quizzes[quiz_id] = quiz_data
        save_quizzes(quizzes)

        summary_text = f"✅ **تم حفظ الكويز بنجاح!**\n\n"
        summary_text += f"📊 عدد الأسئلة: {len(quiz_questions)}\n"
        summary_text += f"🆔 معرف الكويز: {quiz_id}\n\n"
        summary_text += "**معاينة الأسئلة:**\n"

        for i, q in enumerate(quiz_questions[:3], 1):  # عرض أول 3 أسئلة فقط
            summary_text += f"{i}. {q['question'][:50]}...\n"

        if len(quiz_questions) > 3:
            summary_text += f"... و {len(quiz_questions) - 3} أسئلة أخرى"

        del user_data[user_id]
        await query.edit_message_text(summary_text)

    elif query.data == "cancel_quiz":
        if not is_owner(query.from_user.id):
            return

        user_id = query.from_user.id
        if user_id in user_data:
            del user_data[user_id]

        await query.edit_message_text(
            "❌ تم إلغاء إنشاء الكويز وحذف جميع الأسئلة!")

    elif query.data == "stats":
        if not is_owner(query.from_user.id):
            return
        data = load_data()
        buttons = load_buttons()
        custom_buttons = load_custom_buttons()
        quizzes = load_quizzes()
        scores = load_quiz_scores()

        stats_text = f"""📊 إحصائيات البوت:

📝 عدد الردود المحفوظة: {len(data)}
🔗 عدد أزرار الروابط: {len(buttons)}
🔘 عدد الأزرار المخصصة: {len(custom_buttons)}
🧠 عدد الكويزات: {len(quizzes)}
👥 عدد المشاركين: {len(scores)}
👑 مالك البوت: {OWNER_ID}
"""
        keyboard = [[
            InlineKeyboardButton("🔙 العودة", callback_data="admin_panel")
        ]]
        await query.edit_message_text(
            stats_text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == "back_to_start":
        await start_from_callback(query)


async def start_from_callback(query):
    welcome_text = load_welcome()
    buttons = load_buttons()
    custom_buttons = load_custom_buttons()

    keyboard = []
    for button in buttons:
        keyboard.append(
            [InlineKeyboardButton(button["text"], url=button["url"])])

    # إضافة الأزرار المخصصة
    for button_id, button_data in custom_buttons.items():
        keyboard.append([
            InlineKeyboardButton(button_data["text"],
                                 callback_data=f"custom_btn_{button_id}")
        ])

    if is_owner(query.from_user.id):
        keyboard.append([
            InlineKeyboardButton("🔧 لوحة التحكم", callback_data="admin_panel")
        ])

    keyboard.append(
        [InlineKeyboardButton("📋 عرض جميع الكلمات", callback_data="list_all")])

    await query.edit_message_text(welcome_text,
                                  reply_markup=InlineKeyboardMarkup(keyboard))


# ---------------------------- إضافة الردود ----------------------------


async def start_add_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if not is_owner(query.from_user.id):
        await query.edit_message_text("❌ هذا الأمر مخصص للمالك فقط!")
        return ConversationHandler.END

    await query.edit_message_text(
        "📝 أرسل الكلمة المفتاحية التي تريد إضافة رد لها:")
    return ADDING_KEYWORD


async def add_keyword(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return ConversationHandler.END

    keyword = update.message.text.lower().strip()
    user_data[update.effective_user.id] = {"keyword": keyword}
    await update.message.reply_text(
        f"✅ تم تحديد الكلمة: {keyword}\n\nالآن أرسل الرد (نص أو ملف أو الاثنين معاً):"
    )
    return ADDING_RESPONSE


async def add_response(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return ConversationHandler.END

    user_id = update.effective_user.id
    if user_id not in user_data:
        await update.message.reply_text("❌ حدث خطأ، ابدأ من جديد!")
        return ConversationHandler.END

    keyword = user_data[user_id]["keyword"]
    data = load_data()

    response_data = {"text": "", "file_id": "", "buttons": []}

    # حفظ النص إذا وجد
    if update.message.text:
        response_data["text"] = update.message.text

    # حفظ الملف إذا وجد
    if update.message.document:
        response_data["file_id"] = update.message.document.file_id
    elif update.message.photo:
        response_data["file_id"] = update.message.photo[-1].file_id
    elif update.message.video:
        response_data["file_id"] = update.message.video.file_id
    elif update.message.audio:
        response_data["file_id"] = update.message.audio.file_id
    elif update.message.voice:
        response_data["file_id"] = update.message.voice.file_id

    data[keyword] = response_data
    save_data(data)

    del user_data[user_id]
    keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]
    await update.message.reply_text(f"✅ تم حفظ الرد للكلمة: {keyword}", reply_markup=InlineKeyboardMarkup(keyboard))
    return ConversationHandler.END


# ---------------------------- إنشاء الاستطلاعات ----------------------------


async def start_create_poll(update: Update,
                            context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return ConversationHandler.END

    await update.message.reply_text("📊 أرسل سؤال الاستطلاع:")
    return ADDING_POLL_QUESTION


async def add_poll_question(update: Update,
                            context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return ConversationHandler.END

    question = update.message.text.strip()
    user_data[update.effective_user.id] = {"poll_question": question}
    await update.message.reply_text(
        f"✅ السؤال: {question}\n\nالآن أرسل خيارات الاستطلاع، كل خيار في سطر منفصل (2-50 خيار):"
    )
    return ADDING_POLL_OPTIONS


async def add_poll_options(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return ConversationHandler.END

    user_id = update.effective_user.id
    if user_id not in user_data:
        await update.message.reply_text("❌ حدث خطأ، ابدأ من جديد!")
        return ConversationHandler.END

    options_text = update.message.text.strip()
    options = [
        option.strip() for option in options_text.split('\n')
        if option.strip()
    ]

    if len(options) < 2:
        await update.message.reply_text(
            "❌ يجب أن يكون هناك خيارين على الأقل! أرسل الخيارات مرة أخرى:")
        return ADDING_POLL_OPTIONS

    if len(options) > 50:
        await update.message.reply_text(
            "❌ الحد الأقصى 50 خيارات! أرسل الخيارات مرة أخرى:")
        return ADDING_POLL_OPTIONS

    question = user_data[user_id]["poll_question"]
    polls = load_polls()

    # إنشاء ID فريد للاستطلاع
    import time
    poll_id = str(int(time.time()))

    poll_data = {
        "question": question,
        "options": options,
        "is_anonymous": True,
        "multiple_answers": False
    }

    polls[poll_id] = poll_data
    save_polls(polls)

    # إرسال الاستطلاع كمعاينة
    await update.message.reply_poll(question=question,
                                    options=options,
                                    is_anonymous=True,
                                    allows_multiple_answers=False)
    keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]
    del user_data[user_id]
    await update.message.reply_text(
        f"✅ تم إنشاء الاستطلاع بنجاح!\n\n📊 السؤال: {question}\n🔢 عدد الخيارات: {len(options)}", reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return ConversationHandler.END


# ---------------------------- إضافة الأزرار المخصصة ----------------------------


async def start_add_custom_button(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if not is_owner(query.from_user.id):
        await query.edit_message_text("❌ هذا الأمر مخصص للمالك فقط!")
        return ConversationHandler.END

    await query.edit_message_text("📝 أرسل نص الزر المخصص:")
    return ADDING_CUSTOM_BUTTON_TEXT


async def add_custom_button_text(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return ConversationHandler.END

    button_text = update.message.text.strip()
    user_data[update.effective_user.id] = {"custom_button_text": button_text}
    await update.message.reply_text(
        f"✅ نص الزر: {button_text}\n\n"
        "الآن أرسل المحتوى:\n"
        "• يمكنك إرسال نص\n"
        "• يمكنك إرسال حتى 10 ملفات\n"
        "• اكتب 'انهاء' عند الانتهاء من إضافة المحتوى"
    )
    return ADDING_CUSTOM_BUTTON_RESPONSE


async def add_custom_button_response(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return ConversationHandler.END

    user_id = update.effective_user.id
    if user_id not in user_data:
        await update.message.reply_text("❌ حدث خطأ، ابدأ من جديد!")
        return ConversationHandler.END

    # التحقق من إنهاء إضافة المحتوى
    if update.message.text and update.message.text.strip().lower() == "انهاء":
        button_text = user_data[user_id]["custom_button_text"]
        custom_buttons = load_custom_buttons()

        # إنشاء ID فريد للزر
        import time
        button_id = str(int(time.time()))

        button_data = {
            "text": button_text,
            "response_text": user_data[user_id].get("response_text", ""),
            "file_ids": user_data[user_id].get("file_ids", []),
            "file_id": ""  # للتوافق مع النظام القديم
        }

        custom_buttons[button_id] = button_data
        save_custom_buttons(custom_buttons)

        files_count = len(button_data["file_ids"])
        keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]
        await update.message.reply_text(
            f"✅ تم إضافة الزر المخصص: {button_text}\n"
            f"📁 عدد الملفات المرفقة: {files_count}\n"
            f"📝 {'يحتوي على نص' if button_data['response_text'] else 'بدون نص'}", reply_markup=InlineKeyboardMarkup(keyboard)
        )

        del user_data[user_id]
        return ConversationHandler.END

    # تهيئة البيانات المؤقتة إذا لم تكن موجودة
    if "file_ids" not in user_data[user_id]:
        user_data[user_id]["file_ids"] = []
    if "response_text" not in user_data[user_id]:
        user_data[user_id]["response_text"] = ""

    # حفظ النص إذا وجد
    if update.message.text:
        if user_data[user_id]["response_text"]:
            user_data[user_id]["response_text"] += "\n" + update.message.text
        else:
            user_data[user_id]["response_text"] = update.message.text

    # حفظ الملف إذا وجد (حد أقصى 10 ملفات)
    file_id = None
    if update.message.document:
        file_id = update.message.document.file_id
    elif update.message.photo:
        file_id = update.message.photo[-1].file_id
    elif update.message.video:
        file_id = update.message.video.file_id
    elif update.message.audio:
        file_id = update.message.audio.file_id
    elif update.message.voice:
        file_id = update.message.voice.file_id

    if file_id and len(user_data[user_id]["file_ids"]) < 10:
        user_data[user_id]["file_ids"].append(file_id)
        current_files = len(user_data[user_id]["file_ids"])
        await update.message.reply_text(
            f"✅ تم إضافة الملف ({current_files}/10)\n"
            f"📁 يمكنك إرسال المزيد من الملفات أو كتابة 'انهاء' للحفظ"
        )
    elif file_id and len(user_data[user_id]["file_ids"]) >= 10:
        await update.message.reply_text("❌ وصلت للحد الأقصى (10 ملفات). اكتب 'انهاء' للحفظ.")

    return ADDING_CUSTOM_BUTTON_RESPONSE


# ---------------------------- إضافة الأزرار ----------------------------


async def start_add_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if not is_owner(query.from_user.id):
        await query.edit_message_text("❌ هذا الأمر مخصص للمالك فقط!")
        return ConversationHandler.END

    await query.edit_message_text("📝 أرسل نص الزر:")
    return ADDING_BUTTON_TEXT


async def add_button_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return ConversationHandler.END

    button_text = update.message.text.strip()
    user_data[update.effective_user.id] = {"button_text": button_text}
    await update.message.reply_text(
        f"✅ نص الزر: {button_text}\n\nالآن أرسل الرابط (URL):")
    return ADDING_BUTTON_URL


async def add_button_url(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return ConversationHandler.END

    user_id = update.effective_user.id
    if user_id not in user_data:
        await update.message.reply_text("❌ حدث خطأ، ابدأ من جديد!")
        return ConversationHandler.END

    button_url = update.message.text.strip()
    button_text = user_data[user_id]["button_text"]

    # التحقق من صحة الرابط
    if not (button_url.startswith("http://")
            or button_url.startswith("https://")):
        await update.message.reply_text(
            "❌ الرابط غير صحيح! يجب أن يبدأ بـ http:// أو https://")
        return ADDING_BUTTON_URL

    buttons = load_buttons()
    buttons.append({"text": button_text, "url": button_url})
    save_buttons(buttons)
    keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]

    del user_data[user_id]
    await update.message.reply_text(
        f"✅ تم إضافة الزر:\n📝 النص: {button_text}\n🔗 الرابط: {button_url}", reply_markup=InlineKeyboardMarkup(keyboard))
    return ConversationHandler.END


# ---------------------------- تعديل رسالة الترحيب ----------------------------


async def set_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("❌ هذا الأمر مخصص للمالك فقط!")
        return

    if context.args:
        text = " ".join(context.args)
        save_welcome(text)
        keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]
        await update.message.reply_text("✅ تم تحديث رسالة الترحيب!", reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await update.message.reply_text("📝 أرسل رسالة الترحيب الجديدة:")


async def handle_welcome_edit(update: Update,
                              context: ContextTypes.DEFAULT_TYPE):
    if is_owner(
            update.effective_user.id
    ) and update.message.reply_to_message and "أرسل الرسالة الجديدة" in update.message.reply_to_message.text:
        new_welcome = update.message.text
        save_welcome(new_welcome)
        keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]
        await update.message.reply_text("✅ تم تحديث رسالة الترحيب!", reply_markup=InlineKeyboardMarkup(keyboard))


# ---------------------------- تعديل الردود ----------------------------


async def edit_reply_content(update: Update,
                             context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return

    user_id = update.effective_user.id
    if user_id not in user_data or "edit_keyword" not in user_data[user_id]:
        await update.message.reply_text("❌ حدث خطأ، ابدأ من جديد!")
        return

    keyword = user_data[user_id]["edit_keyword"]
    data = load_data()

    response_data = {"text": "", "file_id": "", "buttons": []}

    # حفظ النص إذا وجد
    if update.message.text:
        response_data["text"] = update.message.text

    # حفظ الملف إذا وجد
    if update.message.document:
        response_data["file_id"] = update.message.document.file_id
    elif update.message.photo:
        response_data["file_id"] = update.message.photo[-1].file_id
    elif update.message.video:
        response_data["file_id"] = update.message.video.file_id
    elif update.message.audio:
        response_data["file_id"] = update.message.audio.file_id
    elif update.message.voice:
        response_data["file_id"] = update.message.voice.file_id

    data[keyword] = response_data
    save_data(data)
    keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]
    del user_data[user_id]
    await update.message.reply_text(f"✅ تم تعديل الرد للكلمة: {keyword}", reply_markup=InlineKeyboardMarkup(keyboard))


# ---------------------------- تعديل الأزرار ----------------------------


async def edit_button_text_handler(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return

    user_id = update.effective_user.id
    if user_id not in user_data or "edit_button_index" not in user_data[
            user_id]:
        await update.message.reply_text("❌ حدث خطأ، ابدأ من جديد!")
        return

    new_text = update.message.text.strip()
    user_data[user_id]["new_button_text"] = new_text

    buttons = load_buttons()
    btn_index = user_data[user_id]["edit_button_index"]
    current_url = buttons[btn_index]["url"]

    await update.message.reply_text(
        f"✅ النص الجديد: {new_text}\n\nالآن أرسل الرابط الجديد (الحالي: {current_url}):"
    )


async def edit_button_url_handler(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return

    user_id = update.effective_user.id
    if user_id not in user_data or "edit_button_index" not in user_data[
            user_id]:
        await update.message.reply_text("❌ حدث خطأ، ابدأ من جديد!")
        return

    new_url = update.message.text.strip()

    # التحقق من صحة الرابط
    if not (new_url.startswith("http://") or new_url.startswith("https://")):
        await update.message.reply_text(
            "❌ الرابط غير صحيح! يجب أن يبدأ بـ http:// أو https://")
        return

    buttons = load_buttons()
    btn_index = user_data[user_id]["edit_button_index"]
    new_text = user_data[user_id]["new_button_text"]

    buttons[btn_index] = {"text": new_text, "url": new_url}
    save_buttons(buttons)
    keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]

    del user_data[user_id]
    await update.message.reply_text(
        f"✅ تم تعديل الزر:\n📝 النص: {new_text}\n🔗 الرابط: {new_url}", reply_markup=InlineKeyboardMarkup(keyboard))


# ---------------------------- تعديل الأزرار المخصصة ----------------------------


async def edit_custom_button_text_handler(update: Update,
                                          context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return

    user_id = update.effective_user.id
    if user_id not in user_data or "edit_custom_button_id" not in user_data[
            user_id]:
        await update.message.reply_text("❌ حدث خطأ، ابدأ من جديد!")
        return

    new_text = update.message.text.strip()
    user_data[user_id]["new_custom_button_text"] = new_text
# Updated edit instruction text for custom buttons to include the option to send a link.
    await query.edit_message_text(
                f"✅ النص الجديد: {new_text}\n\n"
                "الآن أرسل المحتوى الجديد:\n"
                "• يمكنك إرسال نص\n"
                "• يمكنك إرسال رابط (سيتم استخراجه تلقائياً من النص)\n"
                "• يمكنك إرسال حتى 10 ملفات\n"
                "• اكتب 'انهاء' عند الانتهاء من إضافة المحتوى"
            )


async def edit_custom_button_response_handler(
        update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        return

    user_id = update.effective_user.id
    if user_id not in user_data or "edit_custom_button_id" not in user_data[
            user_id]:
        await update.message.reply_text("❌ حدث خطأ، ابدأ من جديد!")
        return

    # التحقق من إنهاء التعديل
    if update.message.text and update.message.text.strip().lower() == "انهاء":
        button_id = user_data[user_id]["edit_custom_button_id"]
        new_text = user_data[user_id]["new_custom_button_text"]
        custom_buttons = load_custom_buttons()

        button_data = {
            "text": new_text,
            "response_text": user_data[user_id].get("edit_response_text", ""),
            "file_ids": user_data[user_id].get("edit_file_ids", []),
            "file_id": ""  # للتوافق مع النظام القديم
        }

        custom_buttons[button_id] = button_data
        save_custom_buttons(custom_buttons)

        files_count = len(button_data["file_ids"])
        keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]
        await update.message.reply_text(
            f"✅ تم تعديل الزر المخصص: {new_text}\n"
            f"📁 عدد الملفات المرفقة: {files_count}\n"
            f"📝 {'يحتوي على نص' if button_data['response_text'] else 'بدون نص'}", reply_markup=InlineKeyboardMarkup(keyboard)
        )

        del user_data[user_id]
        return

    # تهيئة البيانات المؤقتة إذا لم تكن موجودة
    if "edit_file_ids" not in user_data[user_id]:
        user_data[user_id]["edit_file_ids"] = []
    if "edit_response_text" not in user_data[user_id]:
        user_data[user_id]["edit_response_text"] = ""

    # حفظ النص إذا وجد
    if update.message.text:
        if user_data[user_id]["edit_response_text"]:
            user_data[user_id]["edit_response_text"] += "\n" + update.message.text
        else:
            user_data[user_id]["edit_response_text"] = update.message.text

    # حفظ الملف إذا وجد (حد أقصى 10 ملفات)
    file_id = None
    if update.message.document:
        file_id = update.message.document.file_id
    elif update.message.photo:
        file_id = update.message.photo[-1].file_id
    elif update.message.video:
        file_id = update.message.video.file_id
    elif update.message.audio:
        file_id = update.message.audio.file_id
    elif update.message.voice:
        file_id = update.message.voice.file_id

    if file_id and len(user_data[user_id]["edit_file_ids"]) < 10:
        user_data[user_id]["edit_file_ids"].append(file_id)
        current_files = len(user_data[user_id]["edit_file_ids"])
        await update.message.reply_text(
            f"✅ تم إضافة الملف ({current_files}/10)\n"
            f"📁 يمكنك إرسال المزيد من الملفات أو كتابة 'انهاء' للحفظ"
        )
    elif file_id and len(user_data[user_id]["edit_file_ids"]) >= 10:
        await update.message.reply_text("❌ وصلت للحد الأقصى (10 ملفات). اكتب 'انهاء' للحفظ.")


# ---------------------------- معالجة الرسائل ----------------------------


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # التحقق من وجود النص
    if not update.message or not update.message.text:
        return

    # التحقق من تعديل رسالة الترحيب
    if is_owner(update.effective_user.id) and update.message.reply_to_message:
        if "أرسل الرسالة الجديدة" in update.message.reply_to_message.text:
            new_welcome = update.message.text
            save_welcome(new_welcome)
            keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]
            await update.message.reply_text("✅ تم تحديث رسالة الترحيب!", reply_markup=InlineKeyboardMarkup(keyboard))
            return

    # التحقق من تعديل الردود
    if is_owner(update.effective_user.id
                ) and update.effective_user.id in user_data:
        user_context = user_data[update.effective_user.id]

        # إنشاء استطلاع
        if "creating_poll" in user_context and "poll_question" not in user_context:
            question = update.message.text.strip()
            user_data[update.effective_user.id]["poll_question"] = question
            await update.message.reply_text(
                f"✅ السؤال: {question}\n\nالآن أرسل خيارات الاستطلاع، كل خيار في سطر منفصل (2-10 خيارات):"
            )
            return

        # إضافة خيارات الاستطلاع
        if "poll_question" in user_context and "poll_options" not in user_context:
            options_text = update.message.text.strip()
            options = [
                option.strip() for option in options_text.split('\n')
                if option.strip()
            ]

            if len(options) < 2:
                await update.message.reply_text(
                    "❌ يجب أن يكون هناك خيارين على الأقل! أرسل الخيارات مرة أخرى:"
                )
                return

            if len(options) > 10:
                await update.message.reply_text(
                    "❌ الحد الأقصى 10 خيارات! أرسل الخيارات مرة أخرى:"
                )
                return

            question = user_context["poll_question"]
            polls = load_polls()

            # إنشاء ID فريد للاستطلاع
            import time
            poll_id = str(int(time.time()))

            poll_data = {
                "question": question,
                "options": options,
                "is_anonymous": True,
                "multiple_answers": False
            }

            polls[poll_id] = poll_data
            save_polls(polls)

            # إرسال الاستطلاع كمعاينة
            await update.message.reply_poll(question=question,
                                            options=options,
                                            is_anonymous=True,
                                            allows_multiple_answers=False)
            keyboard = [[InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="back_to_start")]]
            del user_data[update.effective_user.id]
            await update.message.reply_text(
                f"✅ تم إنشاء الاستطلاع بنجاح!\n\n📊 السؤال: {question}\n🔢 عدد الخيارات: {len(options)}", reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return

        # إنشاء كويز
        if "creating_quiz" in user_context and "current_question" not in user_context:
            question = update.message.text.strip()
            user_data[update.effective_user.id]["current_question"] = question
            await update.message.reply_text(
                f"✅ السؤال: {question}\n\nالآن أرسل خيارات هذا السؤال، كل خيار في سطر منفصل (2-10 خيارات):"
            )
            return

        # إضافة خيارات الكويز
        if "current_question" in user_context and "current_options" not in user_context:
            options_text = update.message.text.strip()
            options = [
                option.strip() for option in options_text.split('\n')
                if option.strip()
            ]

            if len(options) < 2:
                await update.message.reply_text(
                    "❌ يجب أن يكون هناك خيارين على الأقل! أرسل الخيارات مرة أخرى:"
                )
                return

            if len(options) > 10:
                await update.message.reply_text(
                    "❌ الحد الأقصى 10 خيارات! أرسل الخيارات مرة أخرى:"
                )
                return

            user_data[update.effective_user.id]["current_options"] = options

            text = "✅ الخيارات المضافة:\n\n"
            for i, option in enumerate(options, 1):
                text += f"{i}. {option}\n"
            text += f"\nالآن أرسل رقم الإجابة الصحيحة (1-{len(options)}):"

            await update.message.reply_text(text)
            return

        # تحديد الإجابة الصحيحة
        if "current_options" in user_context and "current_correct_answer" not in user_context:
            try:
                correct_answer = int(update.message.text.strip()) - 1
                options = user_context["current_options"]

                if correct_answer < 0 or correct_answer >= len(options):
                    await update.message.reply_text(
                        f"❌ رقم غير صحيح! أرسل رقم من 1 إلى {len(options)}:")
                    return

                user_data[update.effective_user.
                          id]["current_correct_answer"] = correct_answer
                await update.message.reply_text(
                    f"✅ الإجابة الصحيحة: {options[correct_answer]}\n\nالآن حدد الوقت المسموح للإجابة بالثواني (10-300 ثانية):"
                )
                return

            except ValueError:
                await update.message.reply_text("❌ يرجى إرسال رقم صحيح!")
                return

        # تحديد وقت الكويز
        if "current_correct_answer" in user_context and "current_time_limit" not in user_context:
            try:
                time_limit = int(update.message.text.strip())

                if time_limit < 10 or time_limit > 300:
                    await update.message.reply_text(
                        "❌ الوقت يجب أن يكون بين 10 و 300 ثانية!")
                    return

                # إضافة السؤال الحالي للقائمة
                question_data = {
                    "question": user_context["current_question"],
                    "options": user_context["current_options"],
                    "correct_answer": user_context["current_correct_answer"],
                    "time_limit": time_limit
                }

                user_data[update.effective_user.id]["quiz_questions"].append(
                    question_data)

                # إزالة البيانات المؤقتة للسؤال الحالي
                del user_data[update.effective_user.id]["current_question"]
                del user_data[update.effective_user.id]["current_options"]
                del user_data[
                    update.effective_user.id]["current_correct_answer"]

                # عرض خيارات المتابعة
                from telegram import InlineKeyboardButton, InlineKeyboardMarkup

                current_count = len(
                    user_data[update.effective_user.id]["quiz_questions"])
                summary_text = f"✅ **تم حفظ السؤال رقم {current_count}!**\n\n"
                summary_text += f"🧠 السؤال: {question_data['question']}\n"
                summary_text += f"✅ الإجابة الصحيحة: {question_data['options'][question_data['correct_answer']]}\n"
                summary_text += f"⏱️ الوقت: {time_limit} ثانية\n\n"
                summary_text += f"📊 إجمالي الأسئلة: {current_count}\n\n"
                summary_text += "ماذا تريد أن تفعل الآن؟"

                keyboard = [[
                    InlineKeyboardButton("➕ إضافة سؤال آخر",
                                         callback_data="add_another_question")
                ],
                            [
                                InlineKeyboardButton("💾 حفظ الكويز",
                                                     callback_data="save_quiz")
                            ],
                            [
                                InlineKeyboardButton(
                                    "❌ إلغاء", callback_data="cancel_quiz")
                            ]]

                await update.message.reply_text(
                    summary_text, reply_markup=InlineKeyboardMarkup(keyboard))
                return

            except ValueError:
                await update.message.reply_text("❌ يرجى إرسال رقم صحيح للوقت!")
                return

        # تعديل رد
        if "edit_keyword" in user_context:
            await edit_reply_content(update, context)
            return

        # تعديل نص الزر
        if "edit_button_index" in user_context and "new_button_text" not in user_context:
            await edit_button_text_handler(update, context)
            return

        # تعديل رابط الزر
        if "edit_button_index" in user_context and "new_button_text" in user_context:
            await edit_button_url_handler(update, context)
            return

        # تعديل نص الزر المخصص
        if "edit_custom_button_id" in user_context and "new_custom_button_text" not in user_context:
            await edit_custom_button_text_handler(update, context)
            return

        # تعديل محتوى الزر المخصص
        if "edit_custom_button_id" in user_context and "new_custom_button_text" in user_context:
            await edit_custom_button_response_handler(update, context)
            return

    # البحث عن الردود التلقائية
    text = update.message.text.lower().strip()
    data = load_data()

    # إذا لم توجد بيانات، لا داعي للبحث
    if not data:
        return

    # البحث في الكلمات المحفوظة (دعم البحث الجزئي)
    for keyword in data.keys():
        if keyword in text:
            entry = data[keyword]

            # إرسال الملف إذا وجد
            if entry.get("file_id"):
                try:
                    await update.message.reply_document(
                        document=entry["file_id"])
                except Exception:
                    continue

            # إرسال النص إذا وجد
            if entry.get("text"):
                await update.message.reply_text(entry["text"])

            # إضافة رسالة /start بعد كل رد
            await update.message.reply_text("🔄 للعودة للقائمة الرئيسية: /start")
            break  # توقف عند أول تطابق


# ---------------------------- إلغاء المحادثة ----------------------------


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in user_data:
        del user_data[user_id]
    await update.message.reply_text("❌ تم إلغاء العملية!")
    return ConversationHandler.END


# ---------------------------- بدء التشغيل ----------------------------


def run():
    app = Application.builder().token(TOKEN).build()

    # إعداد ConversationHandler للردود
    add_reply_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_add_reply, pattern="add_reply")
        ],
        states={
            ADDING_KEYWORD:
            [MessageHandler(filters.TEXT & ~filters.COMMAND, add_keyword)],
            ADDING_RESPONSE: [
                MessageHandler(
                    (filters.TEXT | filters.ATTACHMENT) & ~filters.COMMAND,
                    add_response)
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        per_message=False,
        per_chat=True,
        per_user=True)

    # إعداد ConversationHandler للأزرار
    add_button_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_add_button, pattern="add_button")
        ],
        states={
            ADDING_BUTTON_TEXT:
            [MessageHandler(filters.TEXT & ~filters.COMMAND, add_button_text)],
            ADDING_BUTTON_URL:
            [MessageHandler(filters.TEXT & ~filters.COMMAND, add_button_url)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        per_message=False,
        per_chat=True,
        per_user=True)

    # إعداد ConversationHandler للأزرار المخصصة
    add_custom_button_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_add_custom_button,
                                 pattern="add_custom_button")
        ],
        states={
            ADDING_CUSTOM_BUTTON_TEXT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND,
                               add_custom_button_text)
            ],
            ADDING_CUSTOM_BUTTON_RESPONSE: [
                MessageHandler(
                    (filters.TEXT | filters.ATTACHMENT) & ~filters.COMMAND,
                    add_custom_button_response)
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        per_message=False,
        per_chat=True,
        per_user=True)

    # إعداد ConversationHandler للاستطلاعات
    add_poll_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_create_poll, pattern="create_poll")
        ],
        states={
            ADDING_POLL_QUESTION: [
                MessageHandler(filters.TEXT & ~filters.COMMAND,
                               add_poll_question)
            ],
            ADDING_POLL_OPTIONS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND,
                               add_poll_options)
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        per_message=False,
        per_chat=True,
        per_user=True)

    # إضافة المعالجات
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("setwelcome", set_welcome))
    app.add_handler(CommandHandler("cancel", cancel))
    app.add_handler(add_reply_handler)
    app.add_handler(add_button_handler)
    app.add_handler(add_custom_button_handler)
    app.add_handler(add_poll_handler)
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # تشغيل البوت
    print("🤖 البوت يعمل الآن...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    run()  # عند إضافة الزر


async def add_custom_button(update: Update,
                            context: ContextTypes.DEFAULT_TYPE):
    # ... الكود الحالي ...

    # حفظ الملفات في شكل قائمة
    user_data[update.effective_user.id]["file_ids"] = []

    # ... الكود الحالي ...

    # لحفظ الملفات عند استلامها
    if update.message.document:
        user_data[update.effective_user.id]["file_ids"].append(
            update.message.document.file_id)
    # إضافة أنواع الملفات الأخرى حسب الحاجة

    # عند حفظ الزر
    button_data = {
        "text": button_text,
        "file_ids": user_data[update.effective_user.id]["file_ids"]
    }

    custom_buttons[button_id] = button_data
    save_custom_buttons(custom_buttons)


# عند معالجة الزر لاحقًا
async def handle_custom_button_click(query):
    button_id = query.data.replace("custom_btn_", "")
    custom_buttons = load_custom_buttons()

    if button_id in custom_buttons:
        button_data = custom_buttons[button_id]

        # معالجة لإرسال الملفات المخزنة
        for file_id in button_data["file_ids"]:
            await query.message.reply_document(file_id=file_id)

        await query.answer("✅ تم إرسال الملفات المرفقة!")

# The text prompt for custom button modification has been updated to include instructions for sending text, up to 10 files, and using 'انهاء' to signal completion.

def run_web_server():
    """تشغيل السيرفر الويب"""
    print("🌐 بدء تشغيل السيرفر الويب على المنفذ 5000...")
    uvicorn.run(app, host="0.0.0.0", port=5000, log_level="info")


async def run_telegram_bot():
    """تشغيل بوت التيليجرام"""
    print("🤖 بدء تشغيل بوت التيليجرام...")
    application = Application.builder().token(TOKEN).build()

    # Command handlers
    application.add_handler(CommandHandler("start", start))

    # Conversation handlers
    add_reply_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_add_reply, pattern="add_reply")],
        states={
            ADDING_KEYWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_keyword)],
            ADDING_RESPONSE: [MessageHandler(filters.ALL & ~filters.COMMAND, add_response)]
        },
        fallbacks=[CallbackQueryHandler(cancel, pattern="cancel")],
        per_message=False
    )

    add_button_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_add_button, pattern="add_button")],
        states={
            ADDING_BUTTON_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_button_text)],
            ADDING_BUTTON_URL: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_button_url)]
        },
        fallbacks=[CallbackQueryHandler(cancel, pattern="cancel")],
        per_message=False
    )

    add_custom_button_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_add_custom_button, pattern="add_custom_button")],
        states={
            ADDING_CUSTOM_BUTTON_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_custom_button_text)],
            ADDING_CUSTOM_BUTTON_RESPONSE: [MessageHandler(filters.ALL & ~filters.COMMAND, add_custom_button_response)]
        },
        fallbacks=[CallbackQueryHandler(cancel, pattern="cancel")],
        per_message=False
    )

    add_poll_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_create_poll, pattern="create_poll")],
        states={
            ADDING_POLL_QUESTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_poll_question)],
            ADDING_POLL_OPTIONS: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_poll_options)]
        },
        fallbacks=[CallbackQueryHandler(cancel, pattern="cancel")],
        per_message=False
    )

    application.add_handler(add_reply_handler)
    application.add_handler(add_button_handler)
    application.add_handler(add_custom_button_handler)
    application.add_handler(add_poll_handler)

    # Callback handlers
    application.add_handler(CallbackQueryHandler(button_callback))

    # Message handlers
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.add_handler(MessageHandler(filters.ALL & ~filters.TEXT, handle_all_messages))

    # Start polling
    await application.run_polling()


def main():
    """الدالة الرئيسية - تشغيل السيرفر والبوت بالتوازي"""
    print("🚀 بدء تشغيل النظام المتكامل...")

    # تشغيل السيرفر الويب في thread منفصل
    web_thread = threading.Thread(target=run_web_server, daemon=True)
    web_thread.start()

    print("✅ السيرفر الويب يعمل الآن على: http://localhost:5000")
    print("🤖 البوت يعمل الآن...")

    # تشغيل بوت التيليجرام في الـ main thread
    asyncio.run(run_telegram_bot())


if __name__ == "__main__":
    main()